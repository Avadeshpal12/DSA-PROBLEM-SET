/*
    link: https://www.javatpoint.com/immutable-string

    link: https://www.geeksforgeeks.org/java-string-is-immutable-what-exactly-is-the-meaning/

    link: https://javarevisited.blogspot.com/2010/10/why-string-is-immutable-or-final-in-java.html#axzz6trf6MzwJ
*/