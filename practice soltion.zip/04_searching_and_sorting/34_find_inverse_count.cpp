/*
    link: https://practice.geeksforgeeks.org/problems/inversion-of-array-1587115620/1

    ref: 1_array/16_count_inversion.cpp
*/
